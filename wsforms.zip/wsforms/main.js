let currentEditingCell;

        document.querySelectorAll('.editable-table td').forEach(td => {
            td.addEventListener('click', function(event) {
                if (currentEditingCell) {
                    resetEditing();
                }
                let textarea = document.createElement('textarea');
                textarea.value = this.innerHTML;
                this.innerHTML = '';
                this.appendChild(textarea);
                textarea.focus();

                currentEditingCell = {
                    element: this,
                    originalHTML: this.innerHTML
                };

                document.getElementById('controls').style.display = 'block';
                document.getElementById('ok').addEventListener('click', saveChanges);
                document.getElementById('cancel').addEventListener('click', cancelChanges);
            });
        });

        function saveChanges() {
            currentEditingCell.element.innerHTML = currentEditingCell.element.firstChild.value;
            resetEditing();
        }

        function cancelChanges() {
            currentEditingCell.element.innerHTML = currentEditingCell.originalHTML;
            resetEditing();
        }

        function resetEditing() {
            currentEditingCell = null;
            document.getElementById('controls').style.display = 'none';
            document.getElementById('ok').removeEventListener('click', saveChanges);
            document.getElementById('cancel').removeEventListener('click', cancelChanges);
        }
